import json, os, sys, time
import pygame

def load_level(path):
    with open(path,"r",encoding="utf-8") as f:
        return json.load(f)

def load_npcs(path):
    with open(path,"r",encoding="utf-8") as f:
        return json.load(f)

def run_viewer(project:str):
    level_path = f"assets/{project}_level_meadow_v1.json"
    npcs_path  = f"assets/{project}_npcs.json"
    dialogue_path = f"assets/{project}_dialogue.json"

    if not (os.path.exists(level_path) and os.path.exists(npcs_path)):
        print("No generated assets yet. Run: python run.py --viewer")
        return

    with open(dialogue_path,"r",encoding="utf-8") as f:
        dialogue = json.load(f)

    lvl = load_level(level_path)
    npcs = load_npcs(npcs_path)

    pygame.init()
    tile = 32
    w, h = len(lvl["tiles"][0])*tile, len(lvl["tiles"])*tile
    screen = pygame.display.set_mode((w, h))
    pygame.display.set_caption("Eclipsera Viewer")

    clock = pygame.time.Clock()
    px, py = lvl["player_spawn"]
    player = pygame.Rect(px*tile, py*tile, tile, tile)
    speed = 3

    def draw():
        screen.fill((30,30,30))
        for y,row in enumerate(lvl["tiles"]):
            for x,_ in enumerate(row):
                pygame.draw.rect(screen,(60,60,60), pygame.Rect(x*tile,y*tile,tile,tile),1)
        for obj in lvl.get("objects",[]):
            r = pygame.Rect(obj["x"]*tile, obj["y"]*tile, tile, tile)
            pygame.draw.rect(screen,(200,200,0) if obj["type"]=="coin" else (0,150,200), r)
        for n in npcs:
            r = pygame.Rect(n["x"]*tile, n["y"]*tile, tile, tile)
            pygame.draw.rect(screen,(200,80,80), r)
        pygame.draw.rect(screen,(200,200,200), player)
        pygame.display.flip()

    while True:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit(); return
        keys = pygame.key.get_pressed()
        dx = dy = 0
        if keys[pygame.K_LEFT] or keys[pygame.K_a]: dx -= speed
        if keys[pygame.K_RIGHT] or keys[pygame.K_d]: dx += speed
        if keys[pygame.K_UP] or keys[pygame.K_w]: dy -= speed
        if keys[pygame.K_DOWN] or keys[pygame.K_s]: dy += speed
        player.move_ip(dx,dy)
        draw()
        clock.tick(60)
