import json, os, time

class SkillRegistry:
    def __init__(self):
        self.skills = {}

    def register(self, name, fn):
        self.skills[name] = fn

    # NOTE: parameter renamed to avoid clashing with task args like {"name": "..."}
    def call(self, skill_name, **kwargs):
        if skill_name not in self.skills:
            raise KeyError(f"Unknown skill: {skill_name}")
        return self.skills[skill_name](**kwargs)

    def register_defaults(self):
        self.register("design_game_outline", self._design_game_outline)
        self.register("generate_level_json", self._generate_level_json)
        self.register("generate_npcs", self._generate_npcs)
        self.register("write_dialogue", self._write_dialogue)

    # --- Basic skills ---

    def _design_game_outline(self, goal:str, project:str):
        ts = int(time.time())
        outline = {
            "project": project,
            "timestamp": ts,
            "pitch": f"A tiny vertical slice toward: {goal}",
            "mechanics": ["top-down movement", "collect items", "talk to NPCs"],
            "art": "placeholder sprites",
            "music": "placeholder loop",
            "levels": ["meadow_v1"],
            "npcs": ["guide_v1","merchant_v1"]
        }
        self._write_json(f"data/{project}_outline.json", outline)
        return {"type":"outline", "path": f"data/{project}_outline.json", "summary":"Game outline created."}

    def _generate_level_json(self, name:str, project:str):
        level = {
            "name": name,
            "tiles": [["." for _ in range(16)] for _ in range(12)],
            "player_spawn": [2,2],
            "objects": [{"type":"coin","x":5,"y":5},{"type":"sign","x":8,"y":3,"text":"Hello!"}]
        }
        p = f"assets/{project}_level_{name}.json"
        self._write_json(p, level)
        return {"type":"level", "path": p, "summary": f"Level {name} generated."}

    def _generate_npcs(self, project:str):
        npcs = [
            {"id":"guide_v1","name":"Astra","role":"guide","x":4,"y":4},
            {"id":"merchant_v1","name":"Roux","role":"merchant","x":9,"y":6}
        ]
        p = f"assets/{project}_npcs.json"
        self._write_json(p, npcs)
        return {"type":"npcs", "path": p, "summary": "Basic NPCs created."}

    def _write_dialogue(self, project:str):
        dlg = {
            "guide_v1":[
                {"who":"Astra","text":"Welcome to Eclipsera!"},
                {"who":"Astra","text":"Collect 5 coins and visit Roux."}
            ],
            "merchant_v1":[
                {"who":"Roux","text":"Care to trade a coin for a hint?"}
            ]
        }
        p = f"assets/{project}_dialogue.json"
        self._write_json(p, dlg)
        return {"type":"dialogue","path":p,"summary":"Dialogue written."}

    def _write_json(self, path, obj):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(obj, f, indent=2, ensure_ascii=False)
