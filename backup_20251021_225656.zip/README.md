# Eclipsera
Autonomous agents that create video games (content, levels, NPCs, and runtime).
- Run: `python run.py`
- Export handoff: `python scripts\export_handoff.py`
- Backup zip: `python scripts\backup.py`
